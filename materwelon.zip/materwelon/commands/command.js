// module.exports = {
//     name: 'command',
//     description: "Embeds!",
//     execute(message, args, MessageEmbed) {
//         const newEmbed1 = new MessageEmbed()
//         .setColor('#304281')
//         .setTitle('Rules')
//         .setURL('https://twitch.tv/PyroGamer010')
//         .setDescription('ServerRules')
//         .addFields(
//             {name: 'rule 1', value: 'Be nice'},
//             {name: 'rule 2', value: 'Follow twitch'},
//             {name: 'rule 3', value: 'No memes'}
//         )
//         .setImage('https://www.google.com/url?sa=i&url=https%3A%2F%2Fh20.gg%2Fevents%2Fdutch-college-league-2%2F&psig=AOvVaw0DDWeqs_CTqXKQ_exzhtpN&ust=1639850076450000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCNCfwt6z6_QCFQAAAAAdAAAAABAD')
//         .setFooter('Make sure to check out the rules channel');
    
//         message.channel.send({ embeds: [newEmbed1]});
//     }
// }